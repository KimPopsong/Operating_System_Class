/*
 * Copyright (c) 2001,2003,2004 David H. Hovemeyer <daveho@cs.umd.edu>
 * Copyright (c) 2003,2013,2014 Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 *
 * All rights reserved.
 *
 * This code may not be resdistributed without the permission of the copyright holders.
 * Any student solutions using any of this code base constitute derviced work and may
 * not be redistributed in any form.  This includes (but is not limited to) posting on
 * public forums or web sites, providing copies to (past, present, or future) students
 * enrolled in similar operating systems courses the University of Maryland's CMSC412 course.
 */

#include <conio.h>
#include <process.h>


int main(int argc __attribute__ ((unused)), char **argv
         __attribute__ ((unused))) {

	int length=0;
	int i=0;

	struct Process_Info a[50];
	length=PS(a,sizeof(a));

	Print("%3s %4s %4s %2s %2s %3s %4s \n", "PID", "PPID", "PRIO", "STAT", "AFF", "TIME", "COMMAND");

	for(i=0; i<length; i++) 
	{
		Print("%3d %4d %4d %2c %c %3c %4d %4s \n", a[i].pid, a[i].parent_pid, a[i].priority, a[i].currCore, a[i].status, a[i].affinity, a[i].totalTime, a[i].name);
	}

	// format string for one process line should be "%3d %4d %4d %2c%2c %3c %4d %s\n"
	return 1;
}
