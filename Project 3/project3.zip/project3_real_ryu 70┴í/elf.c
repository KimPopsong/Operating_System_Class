/*
 * ELF executable loading
 * Copyright (c) 2003, Jeffrey K. Hollingsworth <hollings@cs.umd.edu>
 * Copyright (c) 2003, David H. Hovemeyer <daveho@cs.umd.edu>
 *
 * All rights reserved.
 *
 * This code may not be resdistributed without the permission of the copyright holders.
 * Any student solutions using any of this code base constitute derviced work and may
 * not be redistributed in any form.  This includes (but is not limited to) posting on
 * public forums or web sites, providing copies to (past, present, or future) students
 * enrolled in similar operating systems courses the University of Maryland's CMSC412 course.
 *
 * $Revision: 1.31 $
 *
 */

#include <geekos/errno.h>
#include <geekos/kassert.h>
#include <geekos/ktypes.h>
#include <geekos/screen.h>      /* for debug Print() statements */
#include <geekos/pfat.h>
#include <geekos/malloc.h>
#include <geekos/string.h>
#include <geekos/user.h>
#include <geekos/fileio.h>
#include <geekos/elf.h>

#include <geekos/paging.h>

int elfDebug = 0;

/**
 * From the data of an ELF executable, determine how its segments
 * need to be loaded into memory.
 * @param exeFileData buffer containing the executable file
 * @param exeFileLength length of the executable file in bytes
 * @param exeFormat structure describing the executable's segments
 *   and entry address; to be filled in
 * @return 0 if successful, < 0 on error
 */
int Parse_ELF_Executable(char *exeFileData, ulong_t exeFileLength,
                         struct Exe_Format *exeFormat) {
	elfHeader *elf_pointer;    //Pointer to elfHeader structure

							   //exeFileData has all data.

	elf_pointer = (elfHeader *)exeFileData;//set start address

	programHeader *program_pointer;//Pointer to programHeader structure

	program_pointer = (programHeader *)(exeFileData + elf_pointer->phoff);
	//The start address of the program header is in the phoff of the ELF header.

	struct Exe_Segment *Segment_pointer;//Pointer to Exe_segment structure

	Segment_pointer = exeFormat->segmentList;    //Point segment address

	int num = 0;
	int num2=0;
	/*if (exeFileData == 0) { Print("No File");
		return 0;
	}

	if (!((((elf_pointer->ident[0] == 0x7f) && (elf_pointer->ident[1] == 'E'))
		&& (elf_pointer->ident[2] == 'L')) && (elf_pointer->ident[3] == 'F'))) { Print("No ELF File");
		return -1;
	}//check magic number*/
	if (elf_pointer->type == 0) { Print("No file type");
		return -1;
	}
	if (elf_pointer->machine == 0) { Print("No machine");
		return -1;
	}
	if (elf_pointer->version == 0) { Print("Invalid version");
		return -1;
	}
	if (elf_pointer->entry == 0) { Print("No entry point");
		return -1;
	}
	if (elf_pointer->phoff == 0) { Print("No program header table");
		return -1;
	}
	if (elf_pointer->sphoff == 0) { Print("No section header table");
		return -1;
	}
	if (elf_pointer->phnum ==0) { Print("No program header table");
		return -1;
	}
	if (elf_pointer->shnum == 0) { Print("No section header table");
		return -1;
	}
	

	for (num = 0; num < elf_pointer->phnum;num++) {

		
		Segment_pointer->offsetInFile = program_pointer->offset;    
		// Copy the offset in the program header to the offset of the segment

		Segment_pointer->lengthInFile = program_pointer->fileSize;    
		// Copy the number of bytes in the segment in the program header to the legthInFile of the segment

		Segment_pointer->startAddress = program_pointer->vaddr;   
		// Because vaddr in the program header contains the address value of the virtual memory of the first byte of the segment, copy this value to the segment startAddress
		
		Segment_pointer->sizeInMemory = program_pointer->memSize;  
		// The memSize in the program header contains the number of bytes when the segment was loaded into memory, so copy this value to the sizeInMemory of the segment
		
		Segment_pointer->protFlags = program_pointer->flags;    
		//copy permission of combination of VM_READ,VM_WRITE_VM_EXEC

		program_pointer++;   // Increase the pointer value to point to the address of the next program header
		Segment_pointer++;   // Increase the pointer value to point to the next segment address
		
		if(num>=EXE_MAX_SEGMENTS){ // If phnum has garbage value, it infinitely loops. To prevent it, break break statement when the for statement is more than the maximum number of segments.
			break;
		}
		
	}

	exeFormat->numSegments = num;
	// The number of segments is the phnum value in the elf header

	// e_phnum: This value indicates how many entries are in the program header table.

	exeFormat->entryAddr = elf_pointer->entry;    //entry is startaddress.
	return 0;
}
